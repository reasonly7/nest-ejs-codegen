<script setup lang="ts">
import { Button } from 'ant-design-vue'
</script>

<template>
  <div>
    <Button type="primary">Hello, World!</Button>
  </div>
</template>

<style scoped lang="less"></style>
