# antdv-vite-template

A project template using Vue + Vite + Ant Design Vue（一个 vue +vite + ant-design-vue 的项目模版）
